alert("JavaScript works!");


// Robert Louderback
// SDI 0913
// Assignment 2

//variables
var myBreakfast;
var myWork;
var myMeds = 0;


//myProcedure
myBreakfast = confirm("Do you want to eat breakfast?");
if (myBreakfast === true){
    console.log("Happy and Full");
    }else{
    console.log("Ok but you will be hungry later");
};
myWork = confirm("Do you want to go to work today?");
if (myWork === true) {
    console.log("Have a Great Day");
    }else{
    console.log("Another day of freedom");
};
myMeds = prompt("How many medicines do you take this morning?");
while(myMeds < 10) {
    console.log(myMeds + " pills, that's not too bad");
        myMeds++;
};
for (i = 1; i < 3; i++){
    console.log ("Take route "+i);
};
